# CRGRAM — iOS 26 Edition (Web)

CRGRAM — Instagram uslubida ishlaydigan web app (Next.js + Tailwind + Prisma + Cloudinary + NextAuth).

Tez boshlash (local):
1. Fayllarni papkaga joylang (masalan `crgramaiapp/`)
2. `.env.local` faylini yarating va quyidagi environment o‘zgaruvchilarni to‘ldiring
3. Dependencies o‘rnatish:
   - npm install
4. Prisma migrate:
   - npx prisma generate
   - npx prisma migrate dev --name init
5. Dev server:
   - npm run dev
6. Ochiq: http://localhost:3000

Kerakli environment variables (Vercel-ga ham qo‘ying):
- DATABASE_URL="postgresql://USER:PASSWORD@HOST:PORT/DATABASE"
- NEXTAUTH_URL="http://localhost:3000" (production: https://your-app.vercel.app)
- NEXTAUTH_SECRET="random-string"
- GOOGLE_CLIENT_ID
- GOOGLE_CLIENT_SECRET
- EMAIL_SERVER (SMTP URI for NextAuth email provider) — optional for magic link
- EMAIL_FROM
- CLOUDINARY_CLOUD_NAME
- CLOUDINARY_API_KEY
- CLOUDINARY_API_SECRET
- NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME

Deploy (Vercel):
1. GitHub-ga push qiling.
2. Vercel → New Project → import repo.
3. Add Environment Variables (Production & Preview).
4. Build command: `npm run build`
5. Deploy.

Features:
- NextAuth authentication (Google + Email magic link)
- Cloudinary signed uploads (direct client upload)
- Prisma models: User, Post, Media, Comment, Like
- Feed page (LQIP + responsive), Post component, Cloudinary uploader